class_name CameraRig
extends Node2D

@onready var camera: Camera2D = $Camera2D

var players: Array[Player] = []

const BOUNDARY_THICKNESS := 20.0

@onready var left_boundary: AnimatableBody2D = \
	$PlayerBounds/LeftBoundary

@onready var right_boundary: AnimatableBody2D = \
	$PlayerBounds/RightBoundary

@onready var left_boundary_shape: CollisionShape2D = \
	$PlayerBounds/LeftBoundary/CollisionShape2D

@onready var right_boundary_shape: CollisionShape2D = \
	$PlayerBounds/RightBoundary/CollisionShape2D

@export_group("Tracking Margins")
@export_range(0.0, 0.5) var left_margin := 0.2
@export_range(0.0, 0.5) var right_margin := 0.2
@export_range(0.0, 0.5) var top_margin := 0.2
@export_range(0.0, 0.5) var bottom_margin := 0.35

var debug_timer := 0.0

var previous_camera_movement := Vector2.ZERO




func _physics_process(_delta: float) -> void:
	if players.is_empty():
		return

	#var movement := get_required_camera_movement()
#
	#global_position += movement
	#previous_camera_movement = movement

func _ready() -> void:
	EventManager.connect("player_joined", _on_player_joined)
	
	configure_player_bounds()


func _on_player_joined(player: Player) -> void:
	register_player(player)


func configure_player_bounds() -> void:
	var viewport_size := get_viewport_world_size()

	var left_shape := left_boundary_shape.shape as RectangleShape2D
	var right_shape := right_boundary_shape.shape as RectangleShape2D

	left_shape.size = Vector2(
		BOUNDARY_THICKNESS,
		viewport_size.y
	)

	right_shape.size = Vector2(
		BOUNDARY_THICKNESS,
		viewport_size.y
	)

	left_boundary.position = Vector2(
		-viewport_size.x * 0.5 + 100.0,
		0.0
	)

	right_boundary.position = Vector2(
		viewport_size.x * 0.5 - 100.0,
		0.0
	)
	

func get_viewport_world_size() -> Vector2:
	var viewport_size := get_viewport_rect().size
	return viewport_size / camera.zoom
	
	
func get_tracking_rect() -> Rect2:
	var viewport_size := get_viewport_world_size()

	var left := global_position.x - viewport_size.x * 0.5
	var top := global_position.y - viewport_size.y * 0.5

	var tracking_left := left + viewport_size.x * left_margin
	var tracking_right := left + viewport_size.x * (1.0 - right_margin)
	var tracking_top := top + viewport_size.y * top_margin
	var tracking_bottom := top + viewport_size.y * (1.0 - bottom_margin)

	return Rect2(
		Vector2(
			tracking_left, 
			tracking_top
			),
		Vector2(
			tracking_right - tracking_left,
			tracking_bottom - tracking_top
		)
	)


func get_required_camera_movement() -> Vector2:
	if players.is_empty():
		return Vector2.ZERO

	var viewport_size := get_viewport_world_size()

	var left_offset := viewport_size.x * (0.5 - left_margin)
	var right_offset := viewport_size.x * (0.5 - right_margin)
	var top_offset := viewport_size.y * (0.5 - top_margin)
	var bottom_offset := viewport_size.y * (0.5 - bottom_margin)

	var player_bounds := get_player_bounds()

	var min_camera_x := player_bounds.end.x - right_offset
	var max_camera_x := player_bounds.position.x + left_offset

	var min_camera_y := player_bounds.end.y - bottom_offset
	var max_camera_y := player_bounds.position.y + top_offset

	var target_x := get_constrained_camera_position(
		global_position.x,
		min_camera_x,
		max_camera_x
	)

	var target_y := get_constrained_camera_position(
		global_position.y,
		min_camera_y,
		max_camera_y
	)

	return Vector2(
		target_x - global_position.x,
		target_y - global_position.y
	)
	
	
func get_constrained_camera_position(
	current: float,
	minimum: float,
	maximum: float
) -> float:
	if minimum <= maximum:
		return clamp(current, minimum, maximum)

	return current


func register_player(player: Player) -> void:
	if player in players:
		return

	players.append(player)

	if players.size() == 1:
		global_position = player.global_position

	print("CAMERA PLAYER REGISTERED: ", player.name)
	print("CAMERA PLAYERS: ", players.size())


func get_player_bounds() -> Rect2:
	if players.is_empty():
		return Rect2()

	var first_player := players[0]

	var min_x := first_player.global_position.x
	var max_x := first_player.global_position.x
	var min_y := first_player.global_position.y
	var max_y := first_player.global_position.y

	for player in players:
		var position := player.global_position

		min_x = min(min_x, position.x)
		max_x = max(max_x, position.x)
		min_y = min(min_y, position.y)
		max_y = max(max_y, position.y)

	return Rect2(
		Vector2(min_x, min_y),
		Vector2(max_x - min_x, max_y - min_y)
	)
