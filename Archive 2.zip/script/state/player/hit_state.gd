class_name HitState
extends PlayerState

var hit_data: Hit


func set_hit(hit: Hit) -> void:
	hit_data = hit


func enter() -> void:
	super()
	print("HIT STATE")


	if hit_data == null:
		return

	player.physics_component.apply_knockback(
		hit_data.direction,
		hit_data.knockback
	)

func physics_update(
	delta: float,
	_command: PlayerCommand
) -> PlayerTransition.Type:
	player.physics_component.apply_gravity(delta)

	return PlayerTransition.Type.NONE
